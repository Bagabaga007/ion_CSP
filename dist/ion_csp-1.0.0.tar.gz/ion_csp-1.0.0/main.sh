#!/bin/bash

work_dir=$1
nohup python -m src.main_CSP $work_dir > ${work_dir}/main.log 2>&1 &
